import { FormEvent, useMemo, useState } from "react";
import { Link, useLocation } from "wouter";
import {
  AlertTriangle,
  Archive,
  ArrowDownRight,
  ArrowLeftRight,
  ArrowUpRight,
  Bell,
  Boxes,
  Check,
  ChevronRight,
  ClipboardList,
  Download,
  FileText,
  LayoutDashboard,
  LogIn,
  Menu,
  PackagePlus,
  Pencil,
  Plus,
  Search,
  ShieldCheck,
  SlidersHorizontal,
  Sparkles,
  TrendingDown,
  TrendingUp,
  UserRound,
  Warehouse,
  X,
} from "lucide-react";
import { toast } from "sonner";

type Product = {
  id: number;
  name: string;
  sku: string;
  category: string;
  quantity: number;
  minStock: number;
  price: number;
};

type Movement = {
  id: number;
  productId: number;
  productName: string;
  type: "entry" | "exit";
  quantity: number;
  reason: string;
  date: string;
};

type PageKey = "overview" | "products" | "movements" | "alerts" | "reports" | "access";
type ModalState = "product" | "movement" | null;

const initialProducts: Product[] = [
  { id: 1, name: "Câmera Orion 4K", sku: "OR-4K-102", category: "Eletrônicos", quantity: 7, minStock: 12, price: 1280 },
  { id: 2, name: "Mouse Pulse Pro", sku: "PU-MP-221", category: "Periféricos", quantity: 38, minStock: 15, price: 219.9 },
  { id: 3, name: "Cabo USB-C Trançado", sku: "CB-UC-480", category: "Acessórios", quantity: 116, minStock: 40, price: 39.9 },
  { id: 4, name: "Hub Atlas 8 em 1", sku: "AT-HB-633", category: "Acessórios", quantity: 9, minStock: 10, price: 349 },
  { id: 5, name: "Teclado Nova 75", sku: "NV-TK-784", category: "Periféricos", quantity: 24, minStock: 10, price: 629.9 },
  { id: 6, name: "Fone Loop ANC", sku: "LP-FN-910", category: "Áudio", quantity: 14, minStock: 18, price: 789 },
];

const initialMovements: Movement[] = [
  { id: 1, productId: 5, productName: "Teclado Nova 75", type: "exit", quantity: 4, reason: "Pedido #48291", date: "2026-10-15T10:12:00" },
  { id: 2, productId: 3, productName: "Cabo USB-C Trançado", type: "entry", quantity: 48, reason: "Recebimento NF 2418", date: "2026-10-15T08:46:00" },
  { id: 3, productId: 1, productName: "Câmera Orion 4K", type: "exit", quantity: 2, reason: "Pedido #48287", date: "2026-10-14T16:30:00" },
  { id: 4, productId: 2, productName: "Mouse Pulse Pro", type: "entry", quantity: 20, reason: "Reposição programada", date: "2026-10-14T11:05:00" },
];

const navigation: { path: string; label: string; key: PageKey; icon: typeof LayoutDashboard }[] = [
  { path: "/", label: "Visão geral", key: "overview", icon: LayoutDashboard },
  { path: "/produtos", label: "Produtos", key: "products", icon: Boxes },
  { path: "/movimentacoes", label: "Movimentações", key: "movements", icon: ArrowLeftRight },
  { path: "/alertas", label: "Estoque baixo", key: "alerts", icon: AlertTriangle },
  { path: "/relatorios", label: "Relatórios", key: "reports", icon: FileText },
  { path: "/acesso", label: "Acesso", key: "access", icon: ShieldCheck },
];


const categories = ["Eletrônicos", "Periféricos", "Acessórios", "Áudio", "Outros"];
const formatCurrency = (value: number) => new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" }).format(value);
const formatNumber = (value: number) => new Intl.NumberFormat("pt-BR").format(value);
const formatDate = (value: string) => new Intl.DateTimeFormat("pt-BR", { day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit" }).format(new Date(value));

function ProductGlyph({ product }: { product: Product }) {
  const tones: Record<string, string> = {
    Eletrônicos: "bg-cyan-100 text-cyan-700",
    Periféricos: "bg-violet-100 text-violet-700",
    Acessórios: "bg-amber-100 text-amber-700",
    Áudio: "bg-rose-100 text-rose-700",
    Outros: "bg-slate-100 text-slate-700",
  };
  return (
    <div className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-xl text-xs font-extrabold ${tones[product.category] ?? tones.Outros}`}>
      {product.name.split(" ").slice(0, 2).map((word) => word[0]).join("")}
    </div>
  );
}

function StockPill({ product }: { product: Product }) {
  const low = product.quantity <= product.minStock;
  return (
    <span className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-[11px] font-bold ${low ? "bg-amber-50 text-amber-700 ring-1 ring-amber-200" : "bg-emerald-50 text-emerald-700 ring-1 ring-emerald-100"}`}>
      <span className={`h-1.5 w-1.5 rounded-full ${low ? "bg-amber-500" : "bg-emerald-500"}`} />
      {low ? "Atenção" : "Saudável"}
    </span>
  );
}

export default function Home() {
  const [location, setLocation] = useLocation();
  const [products, setProducts] = useState<Product[]>(initialProducts);
  const [movements, setMovements] = useState<Movement[]>(initialMovements);
  const [modal, setModal] = useState<ModalState>(null);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [productSearch, setProductSearch] = useState("");
  const [globalSearch, setGlobalSearch] = useState("");
  const [categoryFilter, setCategoryFilter] = useState("Todos");
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [hasGeneratedReport, setHasGeneratedReport] = useState(false);
  const [authenticated, setAuthenticated] = useState(true);
  const [productForm, setProductForm] = useState({ name: "", sku: "", category: "Eletrônicos", quantity: 0, minStock: 10, price: 0 });
  const [movementForm, setMovementForm] = useState<{ productId: number; type: "entry" | "exit"; quantity: number; reason: string }>({
    productId: initialProducts[0].id,
    type: "entry",
    quantity: 1,
    reason: "",
  });

  const currentPage = navigation.find((item) => item.path === location)?.key ?? "overview";
  const currentLabel = navigation.find((item) => item.key === currentPage)?.label ?? "Visão geral";
  const lowStock = useMemo(() => products.filter((product) => product.quantity <= product.minStock), [products]);
  const totalValue = useMemo(() => products.reduce((total, product) => total + product.quantity * product.price, 0), [products]);
  const totalUnits = useMemo(() => products.reduce((total, product) => total + product.quantity, 0), [products]);
  const filteredProducts = useMemo(() => products.filter((product) => {
    const searchable = `${product.name} ${product.sku} ${product.category}`.toLowerCase();
    return searchable.includes(productSearch.toLowerCase()) && (categoryFilter === "Todos" || product.category === categoryFilter);
  }), [products, productSearch, categoryFilter]);

  const openAddProduct = () => {
    setEditingId(null);
    setProductForm({ name: "", sku: "", category: "Eletrônicos", quantity: 0, minStock: 10, price: 0 });
    setModal("product");
  };

  const openEditProduct = (product: Product) => {
    setEditingId(product.id);
    setProductForm({
      name: product.name,
      sku: product.sku,
      category: product.category,
      quantity: product.quantity,
      minStock: product.minStock,
      price: product.price,
    });
    setModal("product");
  };

  const openMovement = (type: "entry" | "exit" = "entry") => {
    setMovementForm((current) => ({ ...current, type, productId: products[0]?.id ?? 0, quantity: 1, reason: "" }));
    setModal("movement");
  };

  const handleProductSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!productForm.name.trim() || !productForm.sku.trim()) {
      toast.error("Informe o nome e o SKU do produto.");
      return;
    }

    if (editingId) {
      setProducts((current) => current.map((product) => product.id === editingId ? { ...productForm, id: editingId } : product));
      toast.success("Produto atualizado com sucesso.");
    } else {
      setProducts((current) => [...current, { ...productForm, id: Date.now() }]);
      toast.success("Produto cadastrado no estoque.");
    }
    setModal(null);
  };

  const handleMovementSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const product = products.find((item) => item.id === movementForm.productId);
    if (!product || movementForm.quantity <= 0) {
      toast.error("Selecione um produto e informe uma quantidade válida.");
      return;
    }
    if (movementForm.type === "exit" && product.quantity < movementForm.quantity) {
      toast.error("A saída não pode superar o saldo disponível.");
      return;
    }

    setProducts((current) => current.map((item) => item.id === product.id ? {
      ...item,
      quantity: item.quantity + (movementForm.type === "entry" ? movementForm.quantity : -movementForm.quantity),
    } : item));
    setMovements((current) => [{
      id: Date.now(),
      productId: product.id,
      productName: product.name,
      type: movementForm.type,
      quantity: movementForm.quantity,
      reason: movementForm.reason.trim() || (movementForm.type === "entry" ? "Entrada manual" : "Saída manual"),
      date: new Date().toISOString(),
    }, ...current]);
    setModal(null);
    toast.success(`${movementForm.type === "entry" ? "Entrada" : "Saída"} registrada e saldo atualizado.`);
  };

  const handleGlobalSearch = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setProductSearch(globalSearch);
    setLocation("/produtos");
    setIsMenuOpen(false);
  };

  const exportReport = () => {
    const content = [
      ["Produto", "SKU", "Categoria", "Saldo", "Estoque mínimo", "Valor em estoque"].join(";"),
      ...products.map((product) => [product.name, product.sku, product.category, product.quantity, product.minStock, (product.quantity * product.price).toFixed(2)].join(";")),
    ].join("\n");
    const url = URL.createObjectURL(new Blob([content], { type: "text/csv;charset=utf-8;" }));
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = "relatorio-estoque-flow.csv";
    anchor.click();
    URL.revokeObjectURL(url);
    toast.success("Relatório CSV preparado para download.");
  };

  const renderOverview = () => (
    <div className="space-y-6 fade-in">
      <section className="relative overflow-hidden rounded-[1.5rem] bg-[#08233e] px-6 py-7 text-white shadow-xl shadow-slate-900/10 sm:px-8 sm:py-8">
        <div className="absolute -right-10 -top-16 h-52 w-52 rounded-full bg-cyan-400/20 blur-2xl" />
        <div className="absolute bottom-0 left-[42%] h-20 w-20 rounded-full border border-cyan-200/15" />
        <div className="relative flex flex-col gap-6 lg:flex-row lg:items-end lg:justify-between">
          <div className="max-w-xl">
            <div className="mb-3 flex items-center gap-2 text-xs font-bold uppercase tracking-[0.18em] text-cyan-200"><Sparkles className="h-3.5 w-3.5" /> Centro de operações</div>
            <h1 className="text-2xl font-extrabold tracking-tight sm:text-3xl">Seu estoque está sob controle.</h1>
            <p className="mt-2 text-sm leading-6 text-slate-300">Acompanhe o giro dos produtos, antecipe reposições e mantenha cada movimentação registrada.</p>
          </div>
          <div className="flex flex-wrap gap-2">
            <button onClick={() => openMovement("entry")} className="inline-flex items-center gap-2 rounded-xl bg-white px-4 py-2.5 text-sm font-extrabold text-[#0a4963] transition hover:bg-cyan-50"><ArrowDownRight className="h-4 w-4" /> Registrar entrada</button>
            <button onClick={() => openMovement("exit")} className="inline-flex items-center gap-2 rounded-xl border border-white/20 bg-white/10 px-4 py-2.5 text-sm font-bold text-white transition hover:bg-white/15"><ArrowUpRight className="h-4 w-4" /> Registrar saída</button>
          </div>
        </div>
      </section>

      <section className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <MetricCard label="Itens em estoque" value={formatNumber(totalUnits)} delta="+8,4%" icon={<Archive className="h-5 w-5" />} tone="cyan" />
        <MetricCard label="Produtos ativos" value={formatNumber(products.length)} delta="+2 este mês" icon={<Boxes className="h-5 w-5" />} tone="violet" />
        <MetricCard label="Valor em estoque" value={formatCurrency(totalValue)} delta="Atualizado agora" icon={<TrendingUp className="h-5 w-5" />} tone="emerald" compact />
        <MetricCard label="Necessitam atenção" value={formatNumber(lowStock.length)} delta="Ação recomendada" icon={<AlertTriangle className="h-5 w-5" />} tone="amber" />
      </section>

      <section className="grid gap-6 xl:grid-cols-[1.45fr_.9fr]">
        <div className="rounded-[1.35rem] border border-slate-200 bg-white p-5 shadow-sm sm:p-6">
          <div className="mb-7 flex items-start justify-between gap-4">
            <div><p className="text-xs font-extrabold uppercase tracking-[.14em] text-slate-400">Ritmo do estoque</p><h2 className="mt-1 text-lg font-extrabold text-slate-800">Movimentações nos últimos 7 dias</h2></div>
            <span className="mono rounded-lg bg-emerald-50 px-2.5 py-1.5 text-xs font-medium text-emerald-700">+18,2%</span>
          </div>
          <div className="flex h-44 items-end gap-2 sm:gap-4">
            {[42, 67, 50, 83, 61, 93, 72].map((height, index) => (
              <div key={index} className="flex flex-1 flex-col items-center gap-2">
                <div className="group relative flex h-36 w-full items-end rounded-t-md bg-slate-100 px-1">
                  <div className={`progress-fill w-full rounded-t-md ${index === 5 ? "bg-cyan-500" : "bg-slate-300 group-hover:bg-cyan-300"}`} style={{ height: `${height}%` }} />
                </div>
                <span className="text-[10px] font-bold text-slate-400">{["Qui", "Sex", "Sáb", "Dom", "Seg", "Ter", "Hoje"][index]}</span>
              </div>
            ))}
          </div>
          <div className="mt-5 flex items-center gap-5 border-t border-slate-100 pt-4 text-xs font-semibold text-slate-500"><span className="flex items-center gap-2"><span className="h-2.5 w-2.5 rounded-sm bg-cyan-500" /> Entradas e saídas</span><span className="text-slate-400">Pico de atividade: terça-feira</span></div>
        </div>

        <div className="rounded-[1.35rem] border border-slate-200 bg-white p-5 shadow-sm sm:p-6">
          <div className="mb-5 flex items-center justify-between"><div><p className="text-xs font-extrabold uppercase tracking-[.14em] text-slate-400">Prioridade</p><h2 className="mt-1 text-lg font-extrabold text-slate-800">Estoque baixo</h2></div><Link href="/alertas" className="rounded-lg p-2 text-cyan-700 transition hover:bg-cyan-50"><ChevronRight className="h-5 w-5" /></Link></div>
          <div className="space-y-3">
            {lowStock.slice(0, 3).map((product) => <LowStockRow key={product.id} product={product} />)}
            {!lowStock.length && <p className="rounded-xl bg-emerald-50 p-4 text-sm font-semibold text-emerald-700">Tudo certo: nenhum item precisa de reposição.</p>}
          </div>
          <Link href="/alertas" className="mt-5 flex w-full items-center justify-center gap-2 rounded-xl border border-slate-200 py-2.5 text-sm font-bold text-slate-600 transition hover:border-cyan-200 hover:bg-cyan-50 hover:text-cyan-800">Ver todos os alertas <ChevronRight className="h-4 w-4" /></Link>
        </div>
      </section>

      <section className="grid gap-6 xl:grid-cols-[1.45fr_.9fr]">
        <div className="overflow-hidden rounded-[1.35rem] border border-slate-200 bg-white shadow-sm">
          <div className="flex items-center justify-between px-5 py-5 sm:px-6"><div><p className="text-xs font-extrabold uppercase tracking-[.14em] text-slate-400">Atualizações recentes</p><h2 className="mt-1 text-lg font-extrabold text-slate-800">Últimas movimentações</h2></div><Link href="/movimentacoes" className="text-sm font-bold text-cyan-700 hover:text-cyan-900">Ver histórico</Link></div>
          <div className="divide-y divide-slate-100">
            {movements.slice(0, 4).map((movement) => <MovementRow key={movement.id} movement={movement} />)}
          </div>
        </div>
        <div className="rounded-[1.35rem] border border-slate-200 bg-white p-5 shadow-sm sm:p-6">
          <div className="flex h-full flex-col"><div className="flex items-center gap-3"><div className="flex h-10 w-10 items-center justify-center rounded-xl bg-violet-100 text-violet-700"><ClipboardList className="h-5 w-5" /></div><div><p className="text-sm font-extrabold text-slate-800">Resumo de hoje</p><p className="text-xs text-slate-500">15 de outubro de 2026</p></div></div>
            <div className="mt-6 space-y-4"><SummaryLine label="Entradas registradas" value="68 un." color="bg-cyan-500" /><SummaryLine label="Saídas registradas" value="6 un." color="bg-violet-500" /><SummaryLine label="Produtos revisados" value="12" color="bg-emerald-500" /></div>
            <Link href="/relatorios" className="mt-7 inline-flex items-center justify-center gap-2 rounded-xl bg-slate-900 px-4 py-3 text-sm font-bold text-white transition hover:bg-slate-700"><FileText className="h-4 w-4" /> Abrir relatório diário</Link>
          </div>
        </div>
      </section>
    </div>
  );

  const renderProducts = () => (
    <div className="space-y-6 fade-in">
      <PageHeading eyebrow="Catálogo" title="Produtos" description="Consulte, pesquise, edite e cadastre os itens que movem sua operação." action={<button onClick={openAddProduct} className={primaryButton}><Plus className="h-4 w-4" /> Novo produto</button>} />
      <div className="rounded-[1.35rem] border border-slate-200 bg-white shadow-sm">
        <div className="flex flex-col gap-4 border-b border-slate-100 p-5 lg:flex-row lg:items-center lg:justify-between sm:p-6">
          <div className="relative w-full lg:max-w-md"><Search className="absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" /><input value={productSearch} onChange={(event) => setProductSearch(event.target.value)} placeholder="Pesquisar por nome, SKU ou categoria" className="w-full rounded-xl border border-slate-200 bg-slate-50 py-3 pl-10 pr-4 text-sm font-medium outline-none transition focus:border-cyan-400 focus:bg-white focus:ring-4 focus:ring-cyan-100" /></div>
          <div className="flex items-center gap-2"><SlidersHorizontal className="h-4 w-4 text-slate-400" /><select value={categoryFilter} onChange={(event) => setCategoryFilter(event.target.value)} className="rounded-xl border border-slate-200 bg-white px-3 py-2.5 text-sm font-semibold text-slate-600 outline-none focus:border-cyan-400"><option>Todos</option>{categories.map((category) => <option key={category}>{category}</option>)}</select></div>
        </div>
        <div className="space-y-3 p-4 md:hidden">
          {filteredProducts.map((product) => <div key={product.id} className="rounded-2xl border border-slate-100 bg-slate-50/70 p-4"><div className="flex items-start gap-3"><ProductGlyph product={product} /><div className="min-w-0 flex-1"><div className="flex items-start justify-between gap-2"><div><p className="text-sm font-extrabold text-slate-800">{product.name}</p><p className="mono mt-0.5 text-[10px] text-slate-400">{product.sku}</p></div><StockPill product={product} /></div><div className="mt-4 grid grid-cols-2 gap-3 text-xs"><div><p className="font-bold text-slate-400">Saldo</p><p className="mt-1 font-extrabold text-slate-700">{product.quantity} un.</p></div><div><p className="font-bold text-slate-400">Preço un.</p><p className="mt-1 font-extrabold text-slate-700">{formatCurrency(product.price)}</p></div></div></div></div><div className="mt-3 flex items-center justify-between border-t border-slate-200 pt-3"><span className="text-xs font-bold text-slate-500">{product.category}</span><button onClick={() => openEditProduct(product)} className="inline-flex items-center gap-1.5 text-xs font-extrabold text-cyan-700"><Pencil className="h-3.5 w-3.5" /> Editar</button></div></div>)}
          {!filteredProducts.length && <p className="py-10 text-center text-sm font-semibold text-slate-400">Nenhum produto corresponde à pesquisa.</p>}
        </div>
        <div className="hidden overflow-x-auto md:block"><table className="w-full min-w-[760px] text-left"><thead className="border-b border-slate-100 bg-slate-50/60 text-[10px] font-extrabold uppercase tracking-[.14em] text-slate-400"><tr><th className="px-6 py-4">Produto</th><th className="px-4 py-4">Categoria</th><th className="px-4 py-4">Saldo atual</th><th className="px-4 py-4">Preço un.</th><th className="px-4 py-4">Status</th><th className="px-6 py-4 text-right">Ação</th></tr></thead><tbody className="divide-y divide-slate-100">
          {filteredProducts.map((product) => <tr key={product.id} className="transition hover:bg-slate-50/70"><td className="px-6 py-4"><div className="flex items-center gap-3"><ProductGlyph product={product} /><div><p className="text-sm font-extrabold text-slate-800">{product.name}</p><p className="mono mt-0.5 text-[11px] text-slate-400">{product.sku}</p></div></div></td><td className="px-4 py-4"><span className="text-sm font-semibold text-slate-600">{product.category}</span></td><td className="px-4 py-4"><p className="text-sm font-extrabold text-slate-800">{formatNumber(product.quantity)} un.</p><p className="text-[11px] text-slate-400">Mínimo: {product.minStock} un.</p></td><td className="px-4 py-4 text-sm font-bold text-slate-700">{formatCurrency(product.price)}</td><td className="px-4 py-4"><StockPill product={product} /></td><td className="px-6 py-4 text-right"><button onClick={() => openEditProduct(product)} className="inline-flex items-center gap-2 rounded-lg px-3 py-2 text-sm font-bold text-cyan-700 transition hover:bg-cyan-50"><Pencil className="h-3.5 w-3.5" /> Editar</button></td></tr>)}
          {!filteredProducts.length && <tr><td colSpan={6} className="px-6 py-14 text-center text-sm font-semibold text-slate-400">Nenhum produto corresponde à pesquisa.</td></tr>}
        </tbody></table></div>
        <div className="flex items-center justify-between border-t border-slate-100 px-5 py-4 text-xs font-semibold text-slate-400 sm:px-6"><span>{filteredProducts.length} de {products.length} produtos</span><span>Dados atualizados em tempo real</span></div>
      </div>
    </div>
  );

  const renderMovements = () => (
    <div className="space-y-6 fade-in">
      <PageHeading eyebrow="Operação" title="Movimentações" description="Registre cada entrada e saída. O saldo é recalculado automaticamente." action={<div className="flex gap-2"><button onClick={() => openMovement("exit")} className={secondaryButton}><ArrowUpRight className="h-4 w-4" /> Saída</button><button onClick={() => openMovement("entry")} className={primaryButton}><ArrowDownRight className="h-4 w-4" /> Entrada</button></div>} />
      <div className="grid gap-6 xl:grid-cols-[.85fr_1.15fr]">
        <div className="rounded-[1.35rem] bg-[#08233e] p-6 text-white shadow-xl shadow-slate-900/10"><p className="text-xs font-extrabold uppercase tracking-[.14em] text-cyan-200">Fluxo de hoje</p><h2 className="mt-2 text-2xl font-extrabold">Movimente com confiança.</h2><p className="mt-3 text-sm leading-6 text-slate-300">Cada operação atualiza o saldo do produto e fica disponível no histórico do estoque.</p><div className="mt-8 grid grid-cols-2 gap-3"><div className="rounded-xl bg-white/10 p-4"><ArrowDownRight className="h-5 w-5 text-cyan-300" /><p className="mt-4 text-xl font-extrabold">68</p><p className="text-xs font-medium text-slate-300">un. recebidas</p></div><div className="rounded-xl bg-white/10 p-4"><ArrowUpRight className="h-5 w-5 text-violet-300" /><p className="mt-4 text-xl font-extrabold">6</p><p className="text-xs font-medium text-slate-300">un. expedidas</p></div></div><button onClick={() => openMovement("entry")} className="mt-6 inline-flex w-full items-center justify-center gap-2 rounded-xl bg-white py-3 text-sm font-extrabold text-[#0a4963] transition hover:bg-cyan-50"><PackagePlus className="h-4 w-4" /> Registrar movimentação</button></div>
        <div className="overflow-hidden rounded-[1.35rem] border border-slate-200 bg-white shadow-sm"><div className="flex items-center justify-between px-5 py-5 sm:px-6"><div><p className="text-xs font-extrabold uppercase tracking-[.14em] text-slate-400">Histórico</p><h2 className="mt-1 text-lg font-extrabold text-slate-800">Todas as movimentações</h2></div><span className="mono rounded-lg bg-slate-100 px-2.5 py-1.5 text-xs text-slate-500">{movements.length} registros</span></div><div className="divide-y divide-slate-100">{movements.map((movement) => <MovementRow key={movement.id} movement={movement} detailed />)}</div></div>
      </div>
    </div>
  );

  const renderAlerts = () => (
    <div className="space-y-6 fade-in">
      <PageHeading eyebrow="Prevenção" title="Estoque baixo" description="Itens abaixo do nível ideal para você planejar a próxima reposição." action={<button onClick={() => openMovement("entry")} className={primaryButton}><PackagePlus className="h-4 w-4" /> Registrar reposição</button>} />
      <section className="rounded-[1.35rem] border border-amber-200 bg-gradient-to-r from-amber-50 to-white p-5 sm:p-6"><div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between"><div className="flex items-start gap-4"><div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-amber-100 text-amber-700"><AlertTriangle className="h-5 w-5" /></div><div><h2 className="font-extrabold text-amber-950">{lowStock.length} {lowStock.length === 1 ? "produto precisa" : "produtos precisam"} de atenção</h2><p className="mt-1 text-sm text-amber-800">Priorize a reposição dos itens críticos para evitar ruptura nas próximas vendas.</p></div></div><span className="mono w-fit rounded-lg bg-white px-3 py-2 text-xs text-amber-800 ring-1 ring-amber-200">Monitoramento ativo</span></div></section>
      <div className="grid gap-4 lg:grid-cols-2">{lowStock.map((product) => <div key={product.id} className="surface-hover rounded-[1.35rem] border border-slate-200 bg-white p-5 shadow-sm"><div className="flex items-start justify-between gap-4"><div className="flex items-center gap-3"><ProductGlyph product={product} /><div><h2 className="font-extrabold text-slate-800">{product.name}</h2><p className="mono mt-1 text-[11px] text-slate-400">{product.sku}</p></div></div><StockPill product={product} /></div><div className="mt-6"><div className="mb-2 flex justify-between text-xs font-bold"><span className="text-slate-500">Saldo atual</span><span className="text-amber-700">{product.quantity} de {product.minStock} un. mín.</span></div><div className="h-2 overflow-hidden rounded-full bg-slate-100"><div className="h-full rounded-full bg-amber-400" style={{ width: `${Math.max(8, Math.min(100, product.quantity / product.minStock * 100))}%` }} /></div></div><div className="mt-5 flex gap-2"><button onClick={() => { setMovementForm((current) => ({ ...current, productId: product.id, type: "entry" })); setModal("movement"); }} className={primaryButton}><Plus className="h-4 w-4" /> Repor agora</button><button onClick={() => openEditProduct(product)} className={secondaryButton}><Pencil className="h-4 w-4" /> Ajustar mínimo</button></div></div>)}
        {!lowStock.length && <div className="col-span-full rounded-[1.35rem] border border-dashed border-emerald-200 bg-emerald-50 p-12 text-center"><Check className="mx-auto h-8 w-8 text-emerald-600" /><h2 className="mt-3 font-extrabold text-emerald-900">Estoque em excelente estado</h2><p className="mt-1 text-sm text-emerald-700">Nenhum produto está abaixo do estoque mínimo.</p></div>}
      </div>
    </div>
  );

  const renderReports = () => (
    <div className="space-y-6 fade-in">
      <PageHeading eyebrow="Inteligência" title="Relatórios de estoque" description="Transforme a operação diária em decisões mais rápidas e seguras." action={<button onClick={exportReport} className={primaryButton}><Download className="h-4 w-4" /> Exportar CSV</button>} />
      <div className="grid gap-6 xl:grid-cols-[1.25fr_.75fr]"><div className="rounded-[1.35rem] border border-slate-200 bg-white p-6 shadow-sm"><div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between"><div><p className="text-xs font-extrabold uppercase tracking-[.14em] text-slate-400">Panorama atual</p><h2 className="mt-1 text-xl font-extrabold text-slate-800">Composição do estoque</h2></div><button onClick={() => { setHasGeneratedReport(true); toast.success("Relatório atualizado com os dados atuais."); }} className={secondaryButton}><FileText className="h-4 w-4" /> Gerar relatório</button></div><div className="mt-8 space-y-5">{categories.slice(0, 4).map((category, index) => { const amount = products.filter((product) => product.category === category).reduce((sum, product) => sum + product.quantity * product.price, 0); const percent = totalValue ? Math.round(amount / totalValue * 100) : 0; const colors = ["bg-cyan-500", "bg-violet-500", "bg-amber-400", "bg-rose-400"]; return <div key={category}><div className="mb-2 flex items-center justify-between text-sm"><span className="font-bold text-slate-700">{category}</span><span className="mono text-xs text-slate-500">{formatCurrency(amount)} · {percent}%</span></div><div className="h-3 overflow-hidden rounded-full bg-slate-100"><div className={`progress-fill h-full rounded-full ${colors[index]}`} style={{ width: `${Math.max(percent, amount ? 5 : 0)}%` }} /></div></div>; })}</div><div className="mt-8 grid grid-cols-3 gap-3 border-t border-slate-100 pt-6"><ReportStat label="Cobertura" value="24 dias" /><ReportStat label="Giro médio" value="3,8x" /><ReportStat label="Precisão" value="99,2%" /></div></div>
        <div className="rounded-[1.35rem] bg-[#113554] p-6 text-white shadow-xl shadow-slate-900/10"><div className="flex h-full flex-col"><div className="flex h-10 w-10 items-center justify-center rounded-xl bg-cyan-300/20 text-cyan-200"><FileText className="h-5 w-5" /></div><p className="mt-5 text-xs font-extrabold uppercase tracking-[.14em] text-cyan-200">Relatório recomendado</p><h2 className="mt-2 text-xl font-extrabold">Posição de estoque</h2><p className="mt-3 text-sm leading-6 text-slate-300">Uma visão consolidada de saldo, valor e itens críticos para compartilhar com a gestão.</p><div className="mt-6 rounded-xl bg-white/10 p-4"><p className="text-xs font-semibold text-slate-300">Inclui</p><div className="mt-3 space-y-2 text-sm font-bold"><p className="flex items-center gap-2"><Check className="h-4 w-4 text-cyan-300" /> {products.length} produtos ativos</p><p className="flex items-center gap-2"><Check className="h-4 w-4 text-cyan-300" /> {lowStock.length} alertas de reposição</p></div></div><button onClick={() => { setHasGeneratedReport(true); toast.success("Relatório de posição de estoque gerado."); }} className="mt-auto inline-flex items-center justify-center gap-2 rounded-xl bg-white py-3 text-sm font-extrabold text-[#0b3c55] transition hover:bg-cyan-50">{hasGeneratedReport ? <Check className="h-4 w-4" /> : <FileText className="h-4 w-4" />}{hasGeneratedReport ? "Relatório atualizado" : "Gerar agora"}</button></div></div></div>
      <div className="overflow-hidden rounded-[1.35rem] border border-slate-200 bg-white shadow-sm"><div className="flex items-center justify-between px-5 py-5 sm:px-6"><div><p className="text-xs font-extrabold uppercase tracking-[.14em] text-slate-400">Produtos por valor</p><h2 className="mt-1 text-lg font-extrabold text-slate-800">Maiores posições em estoque</h2></div><span className="text-xs font-bold text-slate-400">Atualizado agora</span></div><div className="overflow-x-auto"><table className="w-full min-w-[600px] text-left"><thead className="bg-slate-50 text-[10px] font-extrabold uppercase tracking-[.14em] text-slate-400"><tr><th className="px-6 py-3">Produto</th><th className="px-4 py-3">Saldo</th><th className="px-4 py-3">Valor unitário</th><th className="px-6 py-3 text-right">Posição</th></tr></thead><tbody className="divide-y divide-slate-100">{[...products].sort((a, b) => b.quantity * b.price - a.quantity * a.price).slice(0, 4).map((product) => <tr key={product.id}><td className="px-6 py-4"><div className="flex items-center gap-3"><ProductGlyph product={product} /><span className="text-sm font-extrabold text-slate-800">{product.name}</span></div></td><td className="px-4 py-4 text-sm font-bold text-slate-600">{product.quantity} un.</td><td className="px-4 py-4 text-sm font-bold text-slate-600">{formatCurrency(product.price)}</td><td className="px-6 py-4 text-right text-sm font-extrabold text-slate-800">{formatCurrency(product.quantity * product.price)}</td></tr>)}</tbody></table></div></div>
    </div>
  );

  const renderAccess = () => (
    <div className="space-y-6 fade-in">
      <PageHeading eyebrow="Segurança" title="Acesso e equipe" description="Controle demonstrativo de autenticação e permissões da operação." />
      <div className="grid gap-6 xl:grid-cols-[1.1fr_.9fr]"><div className="rounded-[1.35rem] border border-slate-200 bg-white p-6 shadow-sm"><div className="flex flex-col gap-5 sm:flex-row sm:items-center sm:justify-between"><div className="flex items-center gap-4"><div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br from-cyan-400 to-blue-500 text-lg font-extrabold text-white shadow-lg shadow-cyan-200">AM</div><div><p className="text-xs font-extrabold uppercase tracking-[.14em] text-slate-400">Sessão atual</p><h2 className="mt-1 text-lg font-extrabold text-slate-800">Ana Martins</h2><p className="mt-1 text-sm text-slate-500">Gestora de operações</p></div></div><span className={`inline-flex w-fit items-center gap-2 rounded-full px-3 py-1.5 text-xs font-extrabold ${authenticated ? "bg-emerald-50 text-emerald-700" : "bg-slate-100 text-slate-500"}`}><span className={`h-2 w-2 rounded-full ${authenticated ? "bg-emerald-500" : "bg-slate-400"}`} />{authenticated ? "Autenticada" : "Sessão encerrada"}</span></div><div className="mt-7 grid gap-3 sm:grid-cols-2"><AccessPermission icon={<Boxes className="h-4 w-4" />} title="Produtos" text="Cadastrar e editar itens" /><AccessPermission icon={<ArrowLeftRight className="h-4 w-4" />} title="Movimentações" text="Registrar entradas e saídas" /><AccessPermission icon={<FileText className="h-4 w-4" />} title="Relatórios" text="Gerar e exportar dados" /><AccessPermission icon={<ShieldCheck className="h-4 w-4" />} title="Acesso" text="Administrar a equipe" /></div><button onClick={() => { setAuthenticated((value) => !value); toast.success(authenticated ? "Sessão encerrada em modo demonstração." : "Sessão autenticada em modo demonstração."); }} className="mt-6 inline-flex items-center gap-2 rounded-xl border border-slate-200 px-4 py-3 text-sm font-extrabold text-slate-700 transition hover:border-cyan-200 hover:bg-cyan-50">{authenticated ? <LogIn className="h-4 w-4" /> : <ShieldCheck className="h-4 w-4" />}{authenticated ? "Encerrar sessão demonstrativa" : "Simular autenticação"}</button></div>
        <div className="rounded-[1.35rem] bg-[#08233e] p-6 text-white shadow-xl shadow-slate-900/10"><ShieldCheck className="h-8 w-8 text-cyan-300" /><p className="mt-6 text-xs font-extrabold uppercase tracking-[.14em] text-cyan-200">Autenticação preparada</p><h2 className="mt-2 text-2xl font-extrabold">A operação começa por quem tem permissão.</h2><p className="mt-3 text-sm leading-6 text-slate-300">Esta área representa o ponto de controle de acesso do sistema. A navegação demonstra os estados de sessão e permissões por perfil.</p><div className="mt-7 space-y-3 rounded-xl border border-white/10 bg-white/5 p-4"><p className="flex items-center gap-3 text-sm font-semibold"><Check className="h-4 w-4 text-cyan-300" /> Controle de sessão</p><p className="flex items-center gap-3 text-sm font-semibold"><Check className="h-4 w-4 text-cyan-300" /> Papéis de usuário</p><p className="flex items-center gap-3 text-sm font-semibold"><Check className="h-4 w-4 text-cyan-300" /> Auditoria de operações</p></div></div></div>
    </div>
  );

  const content = currentPage === "overview" ? renderOverview() : currentPage === "products" ? renderProducts() : currentPage === "movements" ? renderMovements() : currentPage === "alerts" ? renderAlerts() : currentPage === "reports" ? renderReports() : renderAccess();

  return (
    <div className="app-shell bg-[#f5f8fc] text-slate-800">
      <aside className="fixed inset-y-0 left-0 z-30 hidden w-72 flex-col bg-[#061c32] p-4 text-slate-300 md:flex">
        <div className="flex items-center gap-3 px-3 py-4"><div className="brand-mark flex h-10 w-10 items-center justify-center rounded-xl text-[#073047]"><Warehouse className="h-5 w-5" /></div><div><p className="text-base font-extrabold tracking-tight text-white">Estoque<span className="text-cyan-300">Flow</span></p><p className="text-[10px] font-bold uppercase tracking-[.16em] text-slate-500">Operações inteligentes</p></div></div>
        <div className="mt-8 px-3 text-[10px] font-extrabold uppercase tracking-[.16em] text-slate-500">Menu principal</div>
        <nav className="mt-3 space-y-1">{navigation.map((item) => { const Icon = item.icon; const active = currentPage === item.key; return <Link key={item.path} href={item.path} className={`sidebar-link flex items-center gap-3 rounded-xl px-3 py-3 text-sm font-bold ${active ? "bg-cyan-400 text-[#04283b] shadow-lg shadow-cyan-900/20" : "text-slate-400 hover:bg-white/7 hover:text-white"}`}><Icon className="h-4.5 w-4.5" /><span>{item.label}</span>{item.key === "alerts" && lowStock.length > 0 && <span className={`ml-auto rounded-full px-2 py-0.5 text-[10px] ${active ? "bg-[#07364b]/20" : "bg-amber-400/15 text-amber-300"}`}>{lowStock.length}</span>}</Link>; })}</nav>
        <div className="mt-auto rounded-2xl border border-white/10 bg-white/5 p-4"><div className="flex items-center gap-2 text-cyan-200"><Sparkles className="h-4 w-4" /><span className="text-xs font-extrabold">Saúde do estoque</span></div><p className="mt-3 text-2xl font-extrabold text-white">92<span className="text-base text-slate-400">/100</span></p><div className="mt-2 h-1.5 overflow-hidden rounded-full bg-white/10"><div className="h-full w-[92%] rounded-full bg-cyan-300" /></div><p className="mt-3 text-xs leading-5 text-slate-400">A operação está estável. {lowStock.length} alerta(s) aguardam ação.</p></div>
        <Link href="/acesso" className="mt-3 flex items-center gap-3 rounded-xl px-3 py-3 transition hover:bg-white/7"><div className="flex h-8 w-8 items-center justify-center rounded-lg bg-white/10 text-xs font-extrabold text-cyan-100">AM</div><div><p className="text-xs font-extrabold text-white">Ana Martins</p><p className="text-[10px] text-slate-500">Gestora</p></div><ChevronRight className="ml-auto h-4 w-4 text-slate-600" /></Link>
      </aside>

      <main className="min-h-screen md:pl-72">
        <header className="sticky top-0 z-20 border-b border-slate-200/80 bg-[#f5f8fc]/90 px-4 py-3 backdrop-blur-lg sm:px-6 lg:px-8"><div className="mx-auto flex max-w-[1500px] items-center gap-3"><button aria-label="Abrir menu" onClick={() => setIsMenuOpen(true)} className="rounded-xl p-2 text-slate-600 hover:bg-slate-200 md:hidden"><Menu className="h-5 w-5" /></button><div className="hidden min-w-0 md:block"><p className="text-xs font-extrabold uppercase tracking-[.14em] text-slate-400">Estoque Flow</p><p className="mt-0.5 text-sm font-extrabold text-slate-800">{currentLabel}</p></div><form onSubmit={handleGlobalSearch} className="relative ml-auto w-full max-w-md"><Search className="absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" /><input value={globalSearch} onChange={(event) => setGlobalSearch(event.target.value)} placeholder="Ir para um produto..." className="w-full rounded-xl border border-slate-200 bg-white py-2.5 pl-10 pr-4 text-sm font-medium outline-none transition focus:border-cyan-400 focus:ring-4 focus:ring-cyan-100" /></form><button onClick={() => setLocation("/alertas")} className="relative rounded-xl border border-slate-200 bg-white p-2.5 text-slate-600 transition hover:border-cyan-200 hover:text-cyan-700"><Bell className="h-4 w-4" />{lowStock.length > 0 && <span className="absolute right-1.5 top-1.5 h-2 w-2 rounded-full bg-amber-400 ring-2 ring-white" />}</button><Link href="/acesso" className="hidden h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-cyan-400 to-blue-500 text-xs font-extrabold text-white sm:flex">AM</Link></div></header>
        <div className="mobile-bottom-safe mx-auto max-w-[1500px] px-4 py-6 sm:px-6 lg:px-8 lg:py-8">{content}</div>
      </main>

      <nav className="fixed bottom-0 left-0 right-0 z-30 flex border-t border-slate-200 bg-white/95 px-2 py-2 backdrop-blur md:hidden">{navigation.slice(0, 5).map((item) => { const Icon = item.icon; const active = currentPage === item.key; return <Link key={item.path} href={item.path} className={`flex flex-1 flex-col items-center gap-1 rounded-lg py-1.5 text-[9px] font-extrabold ${active ? "text-cyan-700" : "text-slate-400"}`}><Icon className="h-4 w-4" />{item.label.split(" ")[0]}</Link>; })}</nav>

      {isMenuOpen && <div className="fixed inset-0 z-50 md:hidden"><button onClick={() => setIsMenuOpen(false)} aria-label="Fechar menu" className="absolute inset-0 bg-slate-950/40" /><aside className="relative flex h-full w-[84%] max-w-xs flex-col bg-[#061c32] p-4 text-white shadow-2xl slide-up"><div className="flex items-center justify-between px-2 py-2"><div className="flex items-center gap-2"><div className="brand-mark flex h-9 w-9 items-center justify-center rounded-xl text-[#073047]"><Warehouse className="h-4 w-4" /></div><span className="font-extrabold">Estoque<span className="text-cyan-300">Flow</span></span></div><button onClick={() => setIsMenuOpen(false)} className="rounded-lg p-2 text-slate-400 hover:bg-white/10"><X className="h-4 w-4" /></button></div><nav className="mt-7 space-y-1">{navigation.map((item) => { const Icon = item.icon; const active = currentPage === item.key; return <Link onClick={() => setIsMenuOpen(false)} key={item.path} href={item.path} className={`flex items-center gap-3 rounded-xl px-3 py-3 text-sm font-bold ${active ? "bg-cyan-400 text-[#04283b]" : "text-slate-300"}`}><Icon className="h-4 w-4" />{item.label}</Link>; })}</nav></aside></div>}

      {modal && <div className="fixed inset-0 z-[60] flex items-end justify-center bg-slate-950/45 p-0 backdrop-blur-sm sm:items-center sm:p-5"><div className="w-full max-w-xl rounded-t-[1.5rem] bg-white shadow-2xl slide-up sm:rounded-[1.5rem]">
        <div className="flex items-center justify-between border-b border-slate-100 px-5 py-5 sm:px-6"><div><p className="text-xs font-extrabold uppercase tracking-[.14em] text-slate-400">{modal === "product" ? "Catálogo" : "Operação"}</p><h2 className="mt-1 text-lg font-extrabold text-slate-800">{modal === "product" ? (editingId ? "Editar produto" : "Cadastrar novo produto") : "Registrar movimentação"}</h2></div><button onClick={() => setModal(null)} className="rounded-xl p-2 text-slate-400 transition hover:bg-slate-100 hover:text-slate-600"><X className="h-5 w-5" /></button></div>
        {modal === "product" ? <form onSubmit={handleProductSubmit} className="p-5 sm:p-6"><div className="grid gap-4 sm:grid-cols-2"><FormField label="Nome do produto" className="sm:col-span-2"><input required value={productForm.name} onChange={(event) => setProductForm({ ...productForm, name: event.target.value })} placeholder="Ex.: Suporte Atlas" className={inputClass} /></FormField><FormField label="SKU"><input required value={productForm.sku} onChange={(event) => setProductForm({ ...productForm, sku: event.target.value })} placeholder="EX-000-001" className={inputClass} /></FormField><FormField label="Categoria"><select value={productForm.category} onChange={(event) => setProductForm({ ...productForm, category: event.target.value })} className={inputClass}>{categories.map((category) => <option key={category}>{category}</option>)}</select></FormField><FormField label="Saldo inicial"><input type="number" min="0" value={productForm.quantity} onChange={(event) => setProductForm({ ...productForm, quantity: Number(event.target.value) })} className={inputClass} /></FormField><FormField label="Estoque mínimo"><input type="number" min="0" value={productForm.minStock} onChange={(event) => setProductForm({ ...productForm, minStock: Number(event.target.value) })} className={inputClass} /></FormField><FormField label="Preço unitário (R$)" className="sm:col-span-2"><input type="number" min="0" step="0.01" value={productForm.price} onChange={(event) => setProductForm({ ...productForm, price: Number(event.target.value) })} className={inputClass} /></FormField></div><div className="mt-6 flex flex-col-reverse gap-2 sm:flex-row sm:justify-end"><button type="button" onClick={() => setModal(null)} className={secondaryButton}>Cancelar</button><button type="submit" className={primaryButton}><Check className="h-4 w-4" /> {editingId ? "Salvar alterações" : "Cadastrar produto"}</button></div></form> : <form onSubmit={handleMovementSubmit} className="p-5 sm:p-6"><div className="grid gap-4 sm:grid-cols-2"><FormField label="Tipo de movimentação" className="sm:col-span-2"><div className="grid grid-cols-2 gap-2"><button type="button" onClick={() => setMovementForm({ ...movementForm, type: "entry" })} className={`flex items-center justify-center gap-2 rounded-xl border px-4 py-3 text-sm font-extrabold transition ${movementForm.type === "entry" ? "border-cyan-300 bg-cyan-50 text-cyan-800" : "border-slate-200 text-slate-500"}`}><ArrowDownRight className="h-4 w-4" /> Entrada</button><button type="button" onClick={() => setMovementForm({ ...movementForm, type: "exit" })} className={`flex items-center justify-center gap-2 rounded-xl border px-4 py-3 text-sm font-extrabold transition ${movementForm.type === "exit" ? "border-violet-300 bg-violet-50 text-violet-800" : "border-slate-200 text-slate-500"}`}><ArrowUpRight className="h-4 w-4" /> Saída</button></div></FormField><FormField label="Produto" className="sm:col-span-2"><select value={movementForm.productId} onChange={(event) => setMovementForm({ ...movementForm, productId: Number(event.target.value) })} className={inputClass}>{products.map((product) => <option key={product.id} value={product.id}>{product.name} — {product.quantity} un.</option>)}</select></FormField><FormField label="Quantidade"><input required type="number" min="1" value={movementForm.quantity} onChange={(event) => setMovementForm({ ...movementForm, quantity: Number(event.target.value) })} className={inputClass} /></FormField><FormField label="Referência"><input value={movementForm.reason} onChange={(event) => setMovementForm({ ...movementForm, reason: event.target.value })} placeholder="NF, pedido, ajuste..." className={inputClass} /></FormField></div><div className="mt-5 rounded-xl bg-slate-50 p-3 text-xs font-semibold text-slate-500">O saldo disponível do produto será atualizado assim que você confirmar esta movimentação.</div><div className="mt-6 flex flex-col-reverse gap-2 sm:flex-row sm:justify-end"><button type="button" onClick={() => setModal(null)} className={secondaryButton}>Cancelar</button><button type="submit" className={primaryButton}><Check className="h-4 w-4" /> Confirmar {movementForm.type === "entry" ? "entrada" : "saída"}</button></div></form>}
      </div></div>}
    </div>
  );
}

const inputClass = "w-full rounded-xl border border-slate-200 bg-white px-3.5 py-3 text-sm font-semibold text-slate-700 outline-none transition placeholder:text-slate-400 focus:border-cyan-400 focus:ring-4 focus:ring-cyan-100";
const primaryButton = "inline-flex items-center justify-center gap-2 rounded-xl bg-cyan-600 px-4 py-2.5 text-sm font-extrabold text-white shadow-lg shadow-cyan-600/15 transition hover:bg-cyan-700 focus:outline-none focus:ring-4 focus:ring-cyan-100";
const secondaryButton = "inline-flex items-center justify-center gap-2 rounded-xl border border-slate-200 bg-white px-4 py-2.5 text-sm font-extrabold text-slate-600 transition hover:border-cyan-200 hover:bg-cyan-50 hover:text-cyan-800";

function MetricCard({ label, value, delta, icon, tone, compact = false }: { label: string; value: string; delta: string; icon: React.ReactNode; tone: "cyan" | "violet" | "emerald" | "amber"; compact?: boolean }) {
  const tones = { cyan: "bg-cyan-100 text-cyan-700", violet: "bg-violet-100 text-violet-700", emerald: "bg-emerald-100 text-emerald-700", amber: "bg-amber-100 text-amber-700" };
  return <div className="metric-card rounded-[1.35rem] border border-slate-200 bg-white p-5 shadow-sm"><div className="flex items-start justify-between"><div className={`flex h-10 w-10 items-center justify-center rounded-xl ${tones[tone]}`}>{icon}</div><span className={`rounded-full px-2.5 py-1 text-[10px] font-extrabold ${tone === "amber" ? "bg-amber-50 text-amber-700" : "bg-slate-50 text-slate-500"}`}>{delta}</span></div><p className="mt-5 text-xs font-extrabold uppercase tracking-[.12em] text-slate-400">{label}</p><p className={`mt-1 font-extrabold tracking-tight text-slate-800 ${compact ? "text-2xl" : "text-3xl"}`}>{value}</p></div>;
}

function PageHeading({ eyebrow, title, description, action }: { eyebrow: string; title: string; description: string; action?: React.ReactNode }) {
  return <section className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between"><div><p className="text-xs font-extrabold uppercase tracking-[.14em] text-cyan-700">{eyebrow}</p><h1 className="mt-1 text-2xl font-extrabold tracking-tight text-slate-900 sm:text-3xl">{title}</h1><p className="mt-2 max-w-2xl text-sm leading-6 text-slate-500">{description}</p></div>{action && <div className="flex shrink-0">{action}</div>}</section>;
}

function LowStockRow({ product }: { product: Product }) {
  return <div className="flex items-center gap-3 rounded-xl bg-slate-50 p-3"><ProductGlyph product={product} /><div className="min-w-0 flex-1"><p className="truncate text-sm font-extrabold text-slate-700">{product.name}</p><p className="mt-0.5 text-[11px] font-semibold text-amber-700">{product.quantity} un. · mínimo {product.minStock}</p></div><TrendingDown className="h-4 w-4 text-amber-500" /></div>;
}

function MovementRow({ movement, detailed = false }: { movement: Movement; detailed?: boolean }) {
  const entry = movement.type === "entry";
  return <div className="flex items-center gap-3 px-5 py-4 sm:px-6"><div className={`flex h-9 w-9 shrink-0 items-center justify-center rounded-xl ${entry ? "bg-cyan-100 text-cyan-700" : "bg-violet-100 text-violet-700"}`}>{entry ? <ArrowDownRight className="h-4 w-4" /> : <ArrowUpRight className="h-4 w-4" />}</div><div className="min-w-0 flex-1"><p className="truncate text-sm font-extrabold text-slate-700">{movement.productName}</p><p className="mt-0.5 truncate text-xs text-slate-400">{detailed ? movement.reason : `${movement.reason} · ${formatDate(movement.date)}`}</p></div>{detailed && <span className="hidden text-xs font-semibold text-slate-400 sm:block">{formatDate(movement.date)}</span>}<div className="text-right"><p className={`text-sm font-extrabold ${entry ? "text-cyan-700" : "text-violet-700"}`}>{entry ? "+" : "−"}{movement.quantity} un.</p><p className="mt-0.5 text-[10px] font-bold uppercase tracking-wide text-slate-400">{entry ? "Entrada" : "Saída"}</p></div></div>;
}

function SummaryLine({ label, value, color }: { label: string; value: string; color: string }) {
  return <div className="flex items-center gap-3"><span className={`h-2.5 w-2.5 rounded-full ${color}`} /><span className="flex-1 text-sm font-semibold text-slate-600">{label}</span><span className="mono text-xs font-medium text-slate-500">{value}</span></div>;
}

function ReportStat({ label, value }: { label: string; value: string }) {
  return <div className="rounded-xl bg-slate-50 p-3"><p className="text-[10px] font-extrabold uppercase tracking-[.1em] text-slate-400">{label}</p><p className="mt-1 text-sm font-extrabold text-slate-700">{value}</p></div>;
}

function AccessPermission({ icon, title, text }: { icon: React.ReactNode; title: string; text: string }) {
  return <div className="flex items-center gap-3 rounded-xl bg-slate-50 p-3"><div className="text-cyan-700">{icon}</div><div><p className="text-sm font-extrabold text-slate-700">{title}</p><p className="text-[11px] font-medium text-slate-400">{text}</p></div></div>;
}

function FormField({ label, children, className = "" }: { label: string; children: React.ReactNode; className?: string }) {
  return <label className={`block ${className}`}><span className="mb-2 block text-xs font-extrabold text-slate-600">{label}</span>{children}</label>;
}
