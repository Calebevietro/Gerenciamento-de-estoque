# Entregas — Estoque Flow

- [x] **Dashboard operacional e navegação**
  - Dashboard responsivo com navegação lateral e visão geral dos principais indicadores de estoque.
  - Interface em português do Brasil, refinada e navegável entre visão geral, produtos, movimentações, alertas, relatórios e acesso.

- [x] **Catálogo de produtos**
  - Cadastro de produtos com os dados essenciais de identificação e controle.
  - Consulta, pesquisa e edição dos produtos cadastrados.

- [x] **Movimentação e saldo**
  - Registro de entradas de estoque por produto.
  - Registro de saídas de estoque por produto.
  - Atualização automática das quantidades disponíveis após cada movimentação.

- [x] **Monitoramento e relatórios**
  - Listagem destacada de produtos com estoque baixo.
  - Geração e visualização de relatórios de estoque.

- [x] **Controle de acesso demonstrativo**
  - Área de autenticação de usuários para controle de acesso, caso habilitada.
